using System;
using System.Collections.Generic;
using HuaweiSmartControl.Core;

internal static class CoreTest
{
    static int fails = 0;

    static void Check(string name, bool ok, string detail)
    {
        Console.WriteLine((ok ? "  PASS  " : "  FAIL  ") + name + (detail != null ? "  -> " + detail : ""));
        if (!ok) fails++;
    }

    static int Main()
    {
        Log.FilePath = null;

        Console.WriteLine("=== Huawei EC ===");
        HwmiClient hwmi = new HwmiClient();
        Console.WriteLine("  available=" + hwmi.Available + "  status=" + hwmi.StatusText);
        HwmiResult tr = hwmi.GetTurboMode();
        Console.WriteLine("  GetTurboMode ok=" + tr.Ok + " err=" + tr.Error);

        Console.WriteLine();
        Console.WriteLine("=== NVIDIA DRS ===");
        using (NvApiDrs nv = new NvApiDrs())
        {
            Check("NVAPI available", nv.Available, nv.StatusText);
            if (nv.Available)
            {
                string err;
                bool ok = nv.OpenSession(out err);
                Check("OpenSession", ok, err);

                if (ok)
                {
                    List<string> profiles = nv.ListProfiles();
                    Console.WriteLine("  profiles found: " + profiles.Count + " first='" + (profiles.Count > 0 ? profiles[0] : "-") + "'");
                    Check("ListProfiles returns entries", profiles.Count > 0, null);

                    IntPtr prof;
                    Check("FindOrCreateProfile", nv.FindOrCreateProfile("HuaweiSmartControl", out prof, out err), err);

                    uint before;
                    Check("GetSetting ANISO", nv.TryGetSetting(prof, DrsSetting.AnisoModeLevel, out before, out err), err + " value=" + before);

                    uint rb;
                    Check("SetSetting ANISO->4", nv.SetSetting(prof, DrsSetting.AnisoModeLevel, 4, out rb, out err), err + " readback=" + rb);

                    uint rb2;
                    Check("SetSetting PREFERRED_PSTATE->1", nv.SetSetting(prof, DrsSetting.PreferredPState, 1, out rb2, out err), err + " readback=" + rb2);

                    string se;
                    Check("SaveSettings", nv.SaveSettings(out se), se);

                    // restore aniso to its original value so the machine is left as found
                    uint rb3;
                    nv.SetSetting(prof, DrsSetting.AnisoModeLevel, before, out rb3, out err);
                    nv.CloseSession();

                    // per application entry - every step runs in its own DRS session
                    string appExe = @"C:\Windows\System32\notepad.exe";
                    Check("EnsureApplicationRegistered", nv.EnsureApplicationRegistered("HuaweiSmartControl - Test", appExe, out err), err);

                    List<string> apps = nv.ListApplications("HuaweiSmartControl - Test");
                    Check("ListApplications shows the app", apps.Count > 0, string.Join(", ", apps.ToArray()));

                    string owner = nv.FindOwnerProfileName(appExe);
                    Check("FindOwnerProfileName", owner == "HuaweiSmartControl - Test", "owner=" + owner);

                    bool ok2 = nv.OpenSession(out err);
                    Check("OpenSession(per-app)", ok2, err);
                    if (ok2)
                    {
                        IntPtr prof2;
                        Check("FindOrCreateProfile(per-app)", nv.FindOrCreateProfile("HuaweiSmartControl - Test", out prof2, out err), err);
                        uint r4;
                        Check("SetSetting in per-app profile", nv.SetSetting(prof2, DrsSetting.AnisoModeLevel, 2, out r4, out err), err + " readback=" + r4);
                        Check("SaveSettings(per-app)", nv.SaveSettings(out se), se);
                        nv.CloseSession();
                    }

                    Check("RemoveApplicationRegistered", nv.RemoveApplicationRegistered(appExe, out err), err);
                    Check("RemoveApplicationRegistered (again, must be a no-op)", nv.RemoveApplicationRegistered(appExe, out err), err);
                }
                nv.CloseSession();
            }
        }

        Console.WriteLine();
        Console.WriteLine("=== nvidia-smi ===");
        NvSmi smi = new NvSmi();
        Check("smi available", smi.Available, smi.StatusText);
        List<GpuTelemetry> gpus = smi.Query();
        Check("Query returns GPU", gpus.Count > 0, null);
        foreach (GpuTelemetry g in gpus)
        {
            Console.WriteLine(string.Format("  GPU{0} {1} | pstate={2} temp={3} power={4}/{5} clk={6}/{7} vram={8}/{9}",
                g.Index, g.Name, g.PState, g.TemperatureGpu, g.PowerDrawWatts, g.PowerLimitWatts,
                g.ClockGr, g.ClockMem, g.MemoryUsedMb, g.MemoryTotalMb));
        }
        double mn, mx; string perr;
        bool range = smi.TryGetPowerLimitRange(0, out mn, out mx, out perr);
        Console.WriteLine("  power limit range supported=" + range + " min=" + mn + " max=" + mx + " " + (perr ?? ""));

        Console.WriteLine();
        Console.WriteLine("=== registry GPU preferences ===");
        GpuRegistry reg = new GpuRegistry();
        string rerr;
        string testExe = @"C:\Windows\System32\notepad.exe";
        Check("SetPreference(high)", reg.SetPreference(testExe, "high", out rerr), rerr);
        Dictionary<string, string> all = reg.LoadAll();
        Console.WriteLine("  entries=" + all.Count);
        bool found = false;
        foreach (var kv in all) if (kv.Key.Equals(testExe, StringComparison.OrdinalIgnoreCase)) { found = true; Console.WriteLine("  value=" + kv.Value); }
        Check("registry value readable", found, null);
        Check("RemovePreference", reg.RemovePreference(testExe, out rerr), rerr);

        Console.WriteLine();
        Console.WriteLine("=== preset manager ===");
        AppSettings st = AppSettings.Load();
        PresetManager pm = new PresetManager { NvApi = new NvApiDrs(), Smi = smi, Hwmi = hwmi, Registry = reg, Settings = st };
        string aerr;
        bool applied = pm.Apply("Balanced", out aerr);
        Console.WriteLine("  applied=" + applied + " err=" + (aerr ?? "-") + " current=" + pm.CurrentPreset);
        Check("preset apply runs", applied, aerr);

        Console.WriteLine();
        Console.WriteLine("=== per application preset ===");
        string gameExe = @"C:\Users\AA\AppData\Local\Temp\opencode\probe\samplegame.exe";
        string perr2;
        Check("ApplyToApplication", pm.ApplyToApplication(gameExe, "Ultra", out perr2), perr2);
        string rerr2;
        Check("RemoveApplicationProfile", pm.RemoveApplicationProfile(gameExe, out rerr2), rerr2);

        Console.WriteLine();
        Console.WriteLine("=== launcher ===");
        GameLauncher launcher = new GameLauncher();
        string icd = GameLauncher.FindNvidiaVulkanIcd();
        string ogl = GameLauncher.FindNvidiaOpenGlIcd();
        Console.WriteLine("  vulkan ICD = " + (icd ?? "(none on this host)"));
        Console.WriteLine("  opengl ICD = " + (ogl ?? "(none on this host)"));
        Check("launcher constructs", launcher != null, null);

        Console.WriteLine();
        Console.WriteLine(fails == 0 ? "ALL CHECKS PASSED" : (fails + " CHECK(S) FAILED"));
        return fails == 0 ? 0 : 1;
    }
}
